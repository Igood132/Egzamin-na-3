package com.example.students.config;

import com.example.students.model.Student;
import com.example.students.repository.StudentRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initDatabase(StudentRepository repository) {
        return args -> {
            //repository.save(new Student("", "", ""));
            //http://localhost:8080/api/product
            repository.save(new Student("Artem Alpatov", "Amigo ", "Telefon Amigo "));
            repository.save(new Student("Nastya Pose", "JetMine ", "Gra na telefon JetMine"));
            repository.save(new Student("Vadik Lipki", "Odin ", "Song Odin"));
        };
    }
}
